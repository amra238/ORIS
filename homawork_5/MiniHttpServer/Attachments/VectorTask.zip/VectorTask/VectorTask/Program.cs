﻿namespace Geometry
{
    internal class Library
    {
        public class Vector
        {
            public double X;
            public double Y;
        }

        public class Geometry
        {
            public static double GetLength(Vector vector)
            {
                return Math.Sqrt(vector.X * vector.X + vector.Y * vector.Y);
            }

            public static Vector Add(Vector vector1, Vector vector2)
            {
                var sumX = vector1.X + vector1.X;
                var sumY = vector2.Y + vector2.Y;
                return new Vector { X = sumX, Y = sumY };
            }
        }
    }
}
